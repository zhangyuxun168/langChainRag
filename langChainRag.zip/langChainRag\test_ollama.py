import requests
import json
import sys

# 避免编码问题
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("="*60)
print("Test 1: Check Ollama Service")
print("="*60)
try:
    response = requests.get("http://localhost:11434/api/tags", timeout=3)
    print(f"Ollama service running: {response.status_code}")
    models = response.json().get("models", [])
    print(f"Available models: {[m['name'] for m in models]}")
except Exception as e:
    print(f"Ollama service unavailable: {e}")

print("\n" + "="*60)
print("Test 2: Ollama Embedding API")
print("="*60)

url = "http://localhost:11434/api/embeddings"
payload = {
    "model": "qwen2.5:7b-instruct",
    "prompt": "Hello, this is a test message"
}

try:
    print(f"Request: POST {url}")
    print(f"Payload: {json.dumps(payload)}")
    response = requests.post(url, json=payload, timeout=10)
    print(f"Status code: {response.status_code}")
    print(f"Response: {response.text[:200]}")
    
    if response.status_code == 200:
        result = response.json()
        print(f"Success! Embedding dimension: {len(result.get('embedding', []))}")
    else:
        print(f"Error: {response.text}")
except Exception as e:
    print(f"Request exception: {e}")
