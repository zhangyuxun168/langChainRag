from langchain_community.document_loaders import Docx2txtLoader

test_file = 'g:/langChainRag/uploads/多租户RAG企业私有文档管理系统（完整版）需求文档+开发文档.docx'

print('测试文件:', test_file)

try:
    loader = Docx2txtLoader(test_file)
    docs = loader.load()
    print('成功！加载了', len(docs), '个文档')
    if docs:
        print('文档内容预览:', docs[0].page_content[:200], '...')
except Exception as e:
    print('错误:', str(e))
    import traceback
    traceback.print_exc()