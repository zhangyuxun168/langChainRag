import sys
sys.path.insert(0, '.')

from core.document_processor import DocumentProcessor

processor = DocumentProcessor()
test_file = 'g:/langChainRag/uploads/多租户RAG企业私有文档管理系统（完整版）需求文档+开发文档.docx'

print('测试文件:', test_file)

try:
    docs = processor.process_file(test_file)
    print('成功！处理了', len(docs), '个片段')
except Exception as e:
    print('错误:', str(e))
    import traceback
    traceback.print_exc()