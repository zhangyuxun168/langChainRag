# ==============================================================================
# bge-small-zh-v1.5 模型下载脚本
# ==============================================================================
# 【功能说明】
# 自动下载 bge-small-zh-v1.5 嵌入模型到本地目录
# 
# 【模型信息】
# - 模型名称: BAAI/bge-small-zh-v1.5
# - 向量维度: 384
# - 模型大小: 约 130MB
# - 适用场景: 中文文本嵌入、语义检索、RAG系统
# 
# 【运行方式】
# python download_bge_small_zh.py
# 
# 【依赖】
# 需要安装 huggingface-hub 库
# pip install huggingface-hub
# ==============================================================================

import os
import sys
from huggingface_hub import snapshot_download

def download_model():
    """
    下载 bge-small-zh-v1.5 模型到本地
    """
    # 模型在 HuggingFace 上的仓库名称
    model_repo = "BAAI/bge-small-zh-v1.5"
    
    # 目标目录（本脚本所在目录）
    target_dir = os.path.dirname(os.path.abspath(__file__))
    model_dir = os.path.join(target_dir, "bge-small-zh-v1.5")
    
    # 确保目录存在
    os.makedirs(model_dir, exist_ok=True)
    
    print(f"【下载】开始下载 bge-small-zh-v1.5 模型")
    print(f"【下载】模型仓库: {model_repo}")
    print(f"【下载】目标目录: {model_dir}")
    print(f"【下载】预计大小: 约 130MB")
    print("=" * 60)
    
    try:
        # 使用 huggingface-hub 下载模型
        snapshot_download(
            repo_id=model_repo,
            local_dir=model_dir,
            local_dir_use_symlinks=False,
            resume_download=True  # 支持断点续传
        )
        
        print("=" * 60)
        print("【下载】模型下载完成！")
        print(f"【下载】模型已保存到: {model_dir}")
        
        # 验证下载的文件
        verify_model(model_dir)
        
    except ImportError:
        print("ERROR: 需要安装 huggingface-hub 库")
        print("请运行: pip install huggingface-hub")
        sys.exit(1)
    except Exception as e:
        print(f"ERROR: 下载失败 - {str(e)}")
        sys.exit(1)

def verify_model(model_dir):
    """
    验证模型文件是否完整
    """
    required_files = [
        "config.json",
        "pytorch_model.bin",
        "tokenizer.json",
        "tokenizer_config.json",
        "vocab.txt",
        "model.safetensors"
    ]
    
    print("\n【验证】检查模型文件...")
    missing_files = []
    
    for file_name in required_files:
        file_path = os.path.join(model_dir, file_name)
        if os.path.exists(file_path):
            size = os.path.getsize(file_path) / (1024 * 1024)  # MB
            print(f"✓ {file_name} ({size:.2f} MB)")
        else:
            print(f"✗ {file_name} - 缺失")
            missing_files.append(file_name)
    
    if missing_files:
        print(f"\n【警告】以下文件缺失: {', '.join(missing_files)}")
        print("【警告】请重新运行下载脚本")
    else:
        print("\n【验证】所有必需文件已下载完成！")
        print("【验证】模型可以正常使用")

if __name__ == "__main__":
    download_model()
