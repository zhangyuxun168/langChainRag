# RAG引擎模块 - 负责文档检索和大模型生成回答
import os
import requests
from langchain_core.prompts import PromptTemplate
from langchain_core.documents import Document
from dotenv import load_dotenv
from typing import List, Optional, Dict, Any

from .vector_store import vector_store_manager

load_dotenv()

# 获取项目根目录路径
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ========== 提示词模板 ==========
DEFAULT_PROMPT_TEMPLATE = """
你是一个专业的问答助手，请根据提供的参考文档回答用户的问题。

参考文档：
{context}

用户问题：
{question}

请严格按照以下规则回答：
1. 必须基于提供的参考文档内容进行回答，不要编造信息
2. 如果文档中没有相关信息，请明确说明"未找到相关信息"
3. 回答要简洁明了，不要冗长
4. 如果有多个相关文档，可以综合多个文档的内容进行回答
5. 请用中文回答
"""

# 【调用者】backend/main.py - query()接口、get_config()接口、update_config()接口
# 【功能】RAG引擎核心类：管理大模型配置、执行RAG检索和回答生成
# 【字段】top_k: 检索返回的文档数量(默认3)；temperature: 温度参数(0-1)；
#         llm_api_base: API地址；llm_api_key: API密钥；llm_model_name: 模型名称；
#         prompt_template: 提示词模板
# 【调用】core/vector_store.py: VectorStoreManager.similarity_search()
# 【调用】requests: HTTP请求调用大模型API
class RAGEngine:
    
    # 【调用者】模块加载时自动调用（创建全局实例rag_engine）
    # 【功能】初始化RAG引擎配置，从环境变量读取参数
    # 【配置来源】环境变量 > .env文件 > 默认值
    def __init__(self):
        self.top_k: int = int(os.getenv("TOP_K", 3))
        self.temperature: float = float(os.getenv("TEMPERATURE", 0.7))
        self.llm_api_base: str = os.getenv("LLM_API_BASE", "http://localhost:11434/v1").rstrip('/')
        self.llm_api_key: str = os.getenv("LLM_API_KEY", "")
        self.llm_model_name: str = os.getenv("LLM_MODEL_NAME", "qwen2.5:7b-instruct")
        
        self.prompt_template = PromptTemplate(
            template=DEFAULT_PROMPT_TEMPLATE,
            input_variables=["context", "question"]
        )
    
    # 【调用者】backend/main.py的query()接口（RAG引擎主入口）
    # 【功能】执行RAG查询：向量检索→格式化文档→构建提示词→调用大模型→返回回答
    # 【流程】VectorStoreManager.similarity_search()→format_docs()→PromptTemplate.format()→requests.post()
    # 【错误处理】空问题/集合不存在/无相关文档/API失败
    def query(self, question: str) -> Dict[str, Any]:
        try:
            if not question or not question.strip():
                return {
                    "answer": "请输入有效的问题",
                    "sources": [],
                    "success": True
                }
            
            try:
                docs: List[Document] = vector_store_manager.similarity_search(
                    question, 
                    k=self.top_k,
                    use_local_ollama=True
                )
            except Exception as e:
                if "Collection" in str(e) and "does not exist" in str(e):
                    return {
                        "answer": "抱歉，当前没有已上传的文档。请先在后台管理页面上传文档后再进行查询。",
                        "sources": [],
                        "success": True
                    }
                raise
            
            if not docs or len(docs) == 0:
                return {
                    "answer": "抱歉，在已上传的文档中没有找到相关信息。请尝试更换查询关键词或上传更多相关文档。",
                    "sources": [],
                    "success": True
                }
            
            context: str = self.format_docs(docs)
            prompt: str = self.prompt_template.format(context=context, question=question)
            
            is_ollama = ":" in self.llm_model_name or self.llm_api_base.startswith("http://localhost")
            
            if is_ollama:
                llm_url = f"{self.llm_api_base}/api/chat"
                payload = {
                    "model": self.llm_model_name,
                    "messages": [{"role": "user", "content": prompt}],
                    "stream": False,
                    "temperature": self.temperature
                }
                headers = {"Content-Type": "application/json"}
            else:
                llm_url = f"{self.llm_api_base}/chat/completions"
                payload = {
                    "model": self.llm_model_name,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": self.temperature
                }
                headers = {"Content-Type": "application/json"}
                if self.llm_api_key:
                    headers["Authorization"] = f"Bearer {self.llm_api_key}"
            
            response = requests.post(llm_url, json=payload, headers=headers, timeout=120)
            response.raise_for_status()
            result = response.json()
            
            answer: str = result["message"]["content"] if is_ollama else result["choices"][0]["message"]["content"]
            source_files: List[str] = [doc.metadata.get("source", "unknown") for doc in docs]
            
            return {
                "answer": answer,
                "sources": list(set(source_files)),
                "success": True
            }
        except Exception as e:
            return {
                "answer": f"查询失败: {str(e)}",
                "sources": [],
                "success": False
            }
    
    # 【调用者】backend/main.py的update_config()接口
    # 【功能】运行时动态更新RAG引擎配置参数（支持部分更新）
    # 【验证】top_k必须>0，temperature必须在0-1之间
    def update_config(self,
                      top_k: Optional[int] = None,
                      temperature: Optional[float] = None,
                      llm_api_base: Optional[str] = None,
                      llm_api_key: Optional[str] = None,
                      llm_model_name: Optional[str] = None) -> None:
        # 更新检索文档数量
        if top_k is not None:
            if top_k <= 0:
                raise ValueError("top_k必须大于0")
            self.top_k = top_k
        
        # 更新温度参数
        if temperature is not None:
            if temperature < 0 or temperature > 1:
                raise ValueError("temperature必须在0-1之间")
            self.temperature = temperature
        
        # 更新API地址
        if llm_api_base is not None:
            self.llm_api_base = llm_api_base.rstrip('/')
        
        # 更新API密钥
        if llm_api_key is not None:
            self.llm_api_key = llm_api_key
        
        # 更新模型名称
        if llm_model_name is not None:
            self.llm_model_name = llm_model_name
    
    # 【调用者】backend/main.py的get_config()接口
    # 【功能】获取当前RAG引擎配置，对API密钥进行脱敏处理
    # 【安全】API密钥只返回前6位+***，保护敏感信息
    def get_config(self) -> Dict[str, Any]:
        return {
            "top_k": self.top_k,
            "temperature": self.temperature,
            "llm_api_base": self.llm_api_base,
            "llm_api_key": self.mask_api_key(self.llm_api_key),
            "llm_model_name": self.llm_model_name,
            "embedding_model_name": "bge-m3"
        }

    # 【调用者】get_config()
    # 【功能】对API密钥进行脱敏处理，只显示前6位+***
    # 【安全】保护敏感信息，避免API密钥泄露
    @staticmethod
    def mask_api_key(api_key: str) -> str:
        if not api_key:
            return ""
        if len(api_key) <= 6:
            return api_key
        return api_key[:6] + "***"
    

    
    # 【调用者】RAGEngine.query()
    # 【功能】将文档列表格式化为上下文字符串，用于构建提示词
    # 【格式】--- [来源] ---\n内容，多个文档用空行分隔
    @staticmethod
    def format_docs(docs: List[Document]) -> str:
        formatted_docs = []
        for i, doc in enumerate(docs):
            source = doc.metadata.get("source", f"文档{i+1}")
            content = doc.page_content
            formatted_doc = f"--- [{source}] ---\n{content}"
            formatted_docs.append(formatted_doc)
        
        return "\n\n".join(formatted_docs)
    
    # 【调用者】backend/main.py的get_models()接口
    # 【功能】获取支持的线上模型列表（预留接口，当前返回空列表）
    def get_online_models(self) -> List[str]:
        return []

# 创建RAG引擎实例（全局单例）
rag_engine = RAGEngine()
