import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from core.vector_store import OllamaEmbeddings
import requests

# 测试我们的 OllamaEmbeddings 类
print("="*60)
print("Testing our OllamaEmbeddings class")
print("="*60)

# 创建实例 - 使用 Ollama 格式
embedding = OllamaEmbeddings(
    model_name="qwen2.5:7b-instruct",
    api_base="http://localhost:11434",
    api_format="ollama"
)

print(f"Model name: {embedding.model_name}")
print(f"Base URL: {embedding.base_url}")
print(f"Use OpenAI format: {embedding.use_openai_format}")
print()

# 测试单个嵌入
print("Testing single embedding:")
try:
    result = embedding.embed_query("Hello, test message")
    print(f"Success! Embedding dimension: {len(result)}")
    print(f"First 5 values: {result[:5]}")
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
