# bge-small-zh-v1.5 模型安装说明

## 模型信息

| 属性 | 值 |
|------|-----|
| 模型名称 | BAAI/bge-small-zh-v1.5 |
| 向量维度 | 384 |
| 模型大小 | 约 130MB |
| 适用场景 | 中文文本嵌入、语义检索、RAG系统 |

## 下载方式

### 方式一：使用脚本自动下载（推荐）

```bash
# 安装依赖
pip install huggingface-hub

# 运行下载脚本
python backend/models/download_bge_small_zh.py
```

### 方式二：手动下载

1. **访问 HuggingFace 模型页面**：
   - https://huggingface.co/BAAI/bge-small-zh-v1.5

2. **下载以下文件**：
   - `config.json`
   - `pytorch_model.bin`
   - `tokenizer.json`
   - `tokenizer_config.json`
   - `vocab.txt`
   - `model.safetensors`

3. **创建目录结构**：
   ```
   backend/
   └── models/
       └── bge-small-zh-v1.5/
           ├── config.json
           ├── pytorch_model.bin
           ├── tokenizer.json
           ├── tokenizer_config.json
           ├── vocab.txt
           └── model.safetensors
   ```

## 验证安装

下载完成后，运行以下命令验证：

```python
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("./backend/models/bge-small-zh-v1.5")
embedding = model.encode("测试文本")
print(f"向量维度: {len(embedding)}")  # 应该输出 384
```

## 模型对比

| 模型 | 维度 | 大小 | 速度 | 适用场景 |
|------|-----|------|------|---------|
| bge-small-zh-v1.5 | 384 | ~130MB | 快 | 中文检索、轻量级应用 |
| bge-base-zh-v1.5 | 768 | ~440MB | 中 | 高精度检索 |
| bge-m3 | 1024 | ~1.5GB | 慢 | 多模态检索 |

## 注意事项

1. **依赖安装**：需要安装 `sentence_transformers` 库
   ```bash
   pip install sentence_transformers
   ```

2. **首次加载**：模型首次加载会比较慢，后续会缓存

3. **离线使用**：下载完成后可完全离线使用，无需网络连接
